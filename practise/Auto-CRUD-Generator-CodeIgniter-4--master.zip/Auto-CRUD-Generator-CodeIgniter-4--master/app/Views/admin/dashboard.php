<?= $this->extend('admin/layouts/main') ?>
<?= $this->section('content') ?>
<?= $this->endSection() ?>