<?= $this->extend('admin/layouts/main') ?>
<?= $this->section('content') ?>
<?= $table ?>
<?= $this->endSection() ?>