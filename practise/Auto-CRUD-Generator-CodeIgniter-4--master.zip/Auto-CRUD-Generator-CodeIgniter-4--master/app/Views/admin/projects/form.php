<?= $this->extend('admin/layouts/main') ?>
<?= $this->section('content') ?>
<?= $form ?>
<?= $this->endSection() ?>