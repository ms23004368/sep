<script src=""></script>
<script src="<?php echo base_url('js/main.js');?>"> </script>

<script src="<?php echo base_url('js/bootstrap.bundle.min.js');?>"> </script>

</body>
</html>
