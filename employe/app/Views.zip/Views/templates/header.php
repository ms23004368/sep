<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
<meta charset="utf-8">   

<!-- CSS Files -->
<link rel="stylesheet" href="<?php echo base_url('css/bootstrap.min.css');?>" />
<link rel="stylesheet" href="<?php echo base_url('css/fontawesome.css');?>" />
<link rel="stylesheet" href="<?php echo base_url('css/brands.css');?>" />
<link rel="stylesheet" href="<?php echo base_url('css/solid.css');?>" />
<link rel="stylesheet" href="<?php echo base_url('css/main.css');?>" />
<link rel="stylesheet" href="<?php echo base_url('css/style.css');?>" />

<!-- Title -->
<title></title>
</head>
<style>
</style>
</head>
<body>
